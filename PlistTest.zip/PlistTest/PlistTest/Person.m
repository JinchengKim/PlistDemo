//
//  Person.m
//  PlistTest
//
//  Created by 李金 on 16/5/22.
//  Copyright © 2016年 kingandyoga. All rights reserved.
//

#import "Person.h"

@implementation Person

@end
