//
//  Person.h
//  PlistTest
//
//  Created by 李金 on 16/5/22.
//  Copyright © 2016年 kingandyoga. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject

// 注意：苹果有命名规范的，命名属性时，不能以copy开头。
// 如果下面的属性声明为copyString，会编译不通过。
@property (nonatomic, copy) NSString *copiedString;

// 默认会是什么呢？
@property (nonatomic) NSString *name;
// 默认是strong类型
@property (nonatomic) NSArray *array;

@end