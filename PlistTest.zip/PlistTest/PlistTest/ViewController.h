//
//  ViewController.h
//  PlistTest
//
//  Created by 李金 on 16/5/21.
//  Copyright © 2016年 kingandyoga. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    NSString *personName;
    NSMutableArray *phoneNumbers;
    NSMutableArray *_array;
}



@property (copy, nonatomic) NSString *personName;
@property (retain, nonatomic) NSMutableArray *phoneNumbers;
@end

