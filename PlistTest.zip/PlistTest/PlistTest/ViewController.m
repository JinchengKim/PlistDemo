//
//  ViewController.m
//  PlistTest
//
//  Created by 李金 on 16/5/21.
//  Copyright © 2016年 kingandyoga. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"



@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *phoneLabel1;
@property (weak, nonatomic) IBOutlet UILabel *phoneLabel2;
@property (weak, nonatomic) IBOutlet UIButton *changeButton;

@property (nonatomic, strong) NSMutableArray *array;
@end

@implementation ViewController

@synthesize personName;
@synthesize phoneNumbers;
- (void)setArray:(NSMutableArray *)array {
    if (_array != array) {
        _array = nil;
        
        _array = array;
    }
}

- (NSMutableArray *)array {
    return _array;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    //[self getPlistInfo];
    Person *lili = [[Person alloc] init];
    lili.name = @"LiLi";
    lili.copiedString = @"LiLi\' father is LLL";
    lili.array = @[@"谢谢", @"感谢"];
    
    NSArray *otherArray = lili.array;
    lili = nil;
    NSLog(@"%@", otherArray);
    
    
    __strong NSArray *strongArray = otherArray;
    otherArray = nil;
    // 打印出来正常的结果。
    NSLog(@"strongArray = %@", strongArray);
    
    __weak NSArray * weakArray = strongArray;
    strongArray = nil;
    // 打印出来：null
    NSLog(@"weakArray: %@", weakArray);
    
}

- (void)getPlistInfo {
    NSString *errorDesc = nil;
    NSPropertyListFormat format;
    NSString *plistPath ;
    NSString *rootPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)objectAtIndex:0];
    plistPath = [rootPath stringByAppendingPathComponent:@"Data.plist"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:plistPath]) {
        plistPath = [[NSBundle mainBundle] pathForResource:@"Data" ofType:@"plist"];
    }
    NSData *plistXML = [[NSFileManager defaultManager] contentsAtPath:plistPath];
    NSDictionary *temp = (NSDictionary *)[NSPropertyListSerialization
                                          propertyListFromData:plistXML
                                          mutabilityOption:NSPropertyListMutableContainersAndLeaves
                                          format:&format
                                          errorDescription:&errorDesc];
    if (!temp) {
        NSLog(@"Error reading plist: %@, format: %lu", errorDesc, (unsigned long)format);
    }
    self.personName = [temp objectForKey:@"Name"];
    self.phoneNumbers = [NSMutableArray arrayWithArray:[temp objectForKey:@"Phones"]];
    self.nameLabel.text = [NSString stringWithFormat:@"姓名：%@",self.personName];
    self.phoneLabel1.text = [NSString stringWithFormat:@"电话1: %@",[self.phoneNumbers objectAtIndex:0] ];
     self.phoneLabel2.text = [NSString stringWithFormat:@"电话2: %@",[self.phoneNumbers objectAtIndex:1] ];
}
- (IBAction)changeClick:(id)sender {
    [self changePlistInfo];
}
- (IBAction)updateClick:(id)sender {
    [self getPlistInfo];
}

- (void)changePlistInfo {
    NSArray *name = @[@"李1",@"李2",@"李3",@"李4",@"李5",@"李6"];
    personName = [name objectAtIndex:rand()%5];
    
    NSString *error;
    NSString *rootPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *plistPath = [rootPath stringByAppendingPathComponent:@"Data.plist"];
    NSDictionary *plistDict = [NSDictionary dictionaryWithObjects:
                               [NSArray arrayWithObjects: personName, phoneNumbers, nil]
                                                          forKeys:[NSArray arrayWithObjects: @"Name", @"Phones", nil]];
    NSData *plistData = [NSPropertyListSerialization dataFromPropertyList:plistDict
                                                                   format:NSPropertyListXMLFormat_v1_0
                                                         errorDescription:&error];
    if(plistData) {
        [plistData writeToFile:plistPath atomically:YES];
    }
    else {
        NSLog(@"error");
    }
}

//创建一个plist文件，一个NSDictionary对象（根对象），并加入一个数字；

- (void)codeInitPlist1{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"plist.plist"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    NSMutableDictionary *data;
    
    if ([fileManager fileExistsAtPath: path]) {
        data = [[NSMutableDictionary alloc] initWithContentsOfFile:path];
    }
    else {
        // 没有不存在这个文件，那么创建一个空的字典
        data = [[NSMutableDictionary alloc] init];
    }
    
    //插入数据
    data[@"value"] = @(5);
    [data writeToFile: path atomically:YES];
    
    //读取数据
    NSMutableDictionary *savedStock = [[NSMutableDictionary alloc] initWithContentsOfFile:path];
    int value1;
    value1 = [savedStock[@"value"] intValue];
    NSLog(@"%i",value1);

}


@end
